
To make a sample ECCV paper, copy the contents of this directory
somewhere, and type

 latex eccv2018submission
 bibtex eccv2018submission
 latex eccv2018submission
 latex eccv2018submission

or 

 pdflatex eccv2018submission
 bibtex eccv2018submission
 pdflatex eccv2018submission
 pdflatex eccv2018submission
